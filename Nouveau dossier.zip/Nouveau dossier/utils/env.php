<?php
    
    $_ENV['host']='localhost';
    $_ENV['name']='root';
    $_ENV['dataB']='website';
    $_ENV['password']='';

?>