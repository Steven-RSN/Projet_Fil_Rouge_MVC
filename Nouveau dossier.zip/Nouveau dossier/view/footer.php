 
    <footer>
        <div class="fondGrisFooter"></div>
    </footer>
    <script src="../scripts/script/insc_srcript.js"></script>
</body>
</html>